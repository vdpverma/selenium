import com.thoughtworks.selenium.*;
import com.thoughtworks.selenium.DefaultSelenium;

//--------- To Invoke IE Browser
public class RC_03 
{
	static BrowserConfigurationOptions oBrowserOptions;
	static DefaultSelenium oSelenium;
	static String sBaseUrl = "http://www.bing.com";
	
	static String sRCServer = "localhost";
	static int iRCServerPort = 4444;
	//static String sBrowserType = "*firefox";
	static String sBrowserType = "*iexplore";
	
	
	public static void main(String[] args) 
	{
		RC_Init();
		RC_Open();
		RC_Wait();
		RC_Search();
		RC_Close();
		
	}

	public static void RC_Init()
	{
		
		oBrowserOptions = new BrowserConfigurationOptions();
		//oBrowserOptions.setSingleWindow();
		oBrowserOptions.setMultiWindow();

		
		oSelenium = new DefaultSelenium(sRCServer, iRCServerPort, sBrowserType, sBaseUrl);
	}
	
	public static void RC_Open()
	{
		oSelenium.start(oBrowserOptions);	// will generate session-id for ff
		oSelenium.setTimeout("50000");
		oSelenium.deleteAllVisibleCookies();
		
		oSelenium.open("/"); // open AUT in browser
		oSelenium.waitForPageToLoad("50000");
		oSelenium.windowMaximize();
	}
	
	public static void RC_Wait()
	{
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public static void RC_Search()
	{
		oSelenium.type("id=sb_form_q", "Selenium");
		oSelenium.click("id=sb_form_go");
		oSelenium.waitForPageToLoad("50000");
		
		System.out.println(oSelenium.getTitle());
		System.out.println("------------------------------");
		System.out.println(oSelenium.getBodyText());
	}
	
	public static void RC_Close()
	{
		oSelenium.deleteAllVisibleCookies();
		
		oSelenium.close();  //  closes Browser with AUT
		oSelenium.stop();   // closes browser session
	}
	
}
