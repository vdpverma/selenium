import com.thoughtworks.selenium.DefaultSelenium;

public class RC_01 
{
	static DefaultSelenium oSelenium;
	static String sBaseUrl = "http://www.bing.com";
	
	static String sRCServer = "localhost";
	static int iRCServerPort = 4444;
	static String sBrowserType = "*firefox";
	
	
	public static void main(String[] args) 
	{
		RC_Init();
		RC_Open();
		RC_Wait();
		RC_Close();
		
	}

	public static void RC_Init()
	{
		oSelenium = new DefaultSelenium(sRCServer, iRCServerPort, sBrowserType, sBaseUrl);
	}
	
	public static void RC_Open()
	{
		oSelenium.start();	// will generate session-id for ff
		oSelenium.open("/"); // open AUT in browser
		oSelenium.waitForPageToLoad("50000");
		oSelenium.windowMaximize();
	}
	
	public static void RC_Wait()
	{
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public static void RC_Close()
	{
		oSelenium.close();  //  closes Browser with AUT
		oSelenium.stop();   // closes browser session
	}
	
}
