
var map = new UIMap();

map.addPageset
(
{
    name: 'HomePage',
    description: 'Contains all HomePage elements',
    pathRegexp: '.*'
}
);


map.addElement('HomePage', {
    name: 'ProductsLink'
    , description: 'Product page'
    , locator: "link=*Products*"
});


map.addPageset
(
{
    name: 'ProductsPage',
    description: 'Contains all HomePage elements',
    pathRegexp: 'products'
}
);


map.addElement('ProductsPage', {
    name: 'SearchTextBox'
    , description: 'Product page search text box'
    , locator: "id=myInput"
});

