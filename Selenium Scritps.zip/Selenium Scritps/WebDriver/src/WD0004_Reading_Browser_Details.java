import org.openqa.selenium.*;
import org.openqa.selenium.firefox.*;


public class WD0004_Reading_Browser_Details 
{

	public static void main(String[] args) 
	{
		WebDriver oBrowser;
		
		oBrowser = new FirefoxDriver(); // for firefox
		oBrowser.get("http://www.gmail.com");
		oBrowser.manage().window().maximize();// to maximize browser
		System.out.println("Title : " + oBrowser.getTitle());
		System.out.println("URL   : " + oBrowser.getCurrentUrl());
		System.out.println("windowHandle  : " + oBrowser.getWindowHandle());
		
		System.out.println("Page Source  : \n\n" + oBrowser.getPageSource());
		
		
		
		
		
		oBrowser.quit(); //  to close the browser
		
		
		
		
	}

}
