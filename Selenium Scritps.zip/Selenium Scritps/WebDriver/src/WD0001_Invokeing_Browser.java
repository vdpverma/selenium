import org.openqa.selenium.*;
import org.openqa.selenium.firefox.*;


public class WD0001_Invokeing_Browser 
{

	public static void main(String[] args) 
	{
		WebDriver oBrowser;
		
		oBrowser = new FirefoxDriver(); // for firefox
				
		
	}

}
