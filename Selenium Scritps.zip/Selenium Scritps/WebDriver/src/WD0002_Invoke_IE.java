
import org.openqa.selenium.*;
import org.openqa.selenium.ie.InternetExplorerDriver;



public class WD0002_Invoke_IE 
{

	public static void main(String[] args) 
	{
		WebDriver oBrowser;
		
		oBrowser = new InternetExplorerDriver();// for IE
				
		
	}

}