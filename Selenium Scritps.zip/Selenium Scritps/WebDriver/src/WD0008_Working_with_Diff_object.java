import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;


public class WD0008_Working_with_Diff_object {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		WebDriver oWD = new FirefoxDriver();
		WebElement oLink,oTextBox,oButton,oCheckBox;
		
		oWD.get("http://www.gmail.com");
		oButton = oWD.findElement(By.xpath("//*[@id='link-signup']"));
		oButton.click();
		
		oTextBox = oWD.findElement(By.name("FirstName"));
		oTextBox.sendKeys("Selenium");
		
		// below line also type the text in last textbox
		// oWD.findElement(By.name("LastName")).sendKeys("User");
		
		oTextBox = oWD.findElement(By.name("LastName"));
		oTextBox.sendKeys("User");
		oCheckBox = oWD.findElement(By.name("TermsOfService"));
		oCheckBox.click();
		
		
		// multiple method of identifying link
		oLink = oWD.findElement(By.linkText("Learn more"));
		//oLink = oWD.findElement(By.xpath("//div/div[1]/p/a"));
		//oLink = oWD.findElement(By.partialLinkText(" more"));// if we know the partial link name
		oLink.click();
		
		oWD.quit();
	}

}
