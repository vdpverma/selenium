import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;


public class WD0013_Counting_no_frames_in_Page {

	public static WebDriver oWD;
	public static String URL = "http://selenium.googlecode.com/svn/trunk/docs/api/java/index.html";
	//public static String URL = "http://www.yahoo.com";
	
	public static void main(String[] args) {
		int Fcount;
		if(BrowserInvoke()){
			Fcount = Get_Frames_Count();
			System.out.println("Total no. Frames found : " + Fcount);
			if(Fcount >0){
				Get_All_Frame_Titla();
			}
		}
		Browser_Close();
	}

	public static int Get_Frames_Count() {
		int count = 0;
		try{
			count = oWD.findElements(By.tagName("frame")).size();
		}catch(Exception e){
			count = 0;
		}
		return count;
		
	}

	public static void Get_All_Frame_Titla(){
		int iRow,FCount;
		String FTitle;
		FCount = Get_Frames_Count();
		for(iRow =0 ;iRow < FCount;iRow++)
		{
			FTitle = oWD.findElements(By.tagName("frame")).get(iRow).getAttribute("title");
			if(FTitle.isEmpty())
				System.out.println(iRow+1 + ". Frame Title not found." );
			else
				System.out.println(iRow+1 + ". Frame Title  : " + FTitle );
		}
	}
	
	
	public static boolean BrowserInvoke(){
		try
		{
		oWD = new FirefoxDriver();
		
		oWD.get(URL);
		}catch(Exception e){
			return false;
		}
		return true;
	}
	
	public static void Browser_Close(){
		oWD.close();
	}
}



