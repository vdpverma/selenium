import java.util.Random;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;


public class WD0010_working_with_Radio_button {
	public static WebDriver oWD = new FirefoxDriver();
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		oWD.get("http://www.bing.com");
		
		GetAllRadioDetails(oWD);
		SelectARadiobutton(oWD);
		GetAllRadioDetails(oWD);
		SelectARadiobutton(oWD);
		GetAllRadioDetails(oWD);
		SelectARadiobutton(oWD);
		GetAllRadioDetails(oWD);
		oWD.quit();
	}

	public static void GetAllRadioDetails(WebDriver oWD){
		int iRow;
		boolean bFlag = true;
		
		System.out.println("no. Radio Button : -" + oWD.findElements(By.xpath("//*[@id='sw_filt']/input")).size());
		iRow =1;
		System.out.println("Sl no.\t Name \t Selected");
		
		while(bFlag == true)
		{	if ( oWD.findElements(By.xpath("//*[@id='sw_filt']/input["+iRow+"]")).size()>0 )
				{
					System.out.println( iRow + ". " + oWD.findElement(By.xpath("//*[@id='sw_filt']/label["+iRow+"]")).getText()+ " -> " + oWD.findElement(By.xpath("//*[@id='sw_filt']/input["+iRow+"]")).isSelected());
					iRow++;
				}
			else
			bFlag = false;	
		}
	}
		public static void SelectARadiobutton(WebDriver oWD){
			int iSelect,iTotalRadio;
			boolean bFlag = true;
			Random R = new Random();
			iTotalRadio = oWD.findElements(By.xpath("//*[@id='sw_filt']/input")).size();
			
			while(bFlag){
				iSelect = R.nextInt(iTotalRadio+1);
				if (iSelect != 0)
				{
					oWD.findElement(By.xpath("//*[@id='sw_filt']/input["+iSelect+"]")).click();
					bFlag = false;
				}
			}
			
				
		}
	
	
}
