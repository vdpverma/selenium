import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;


public class WD0014_Switching_Between_Frame {

	public static WebDriver oWD;
	public static String URL = "http://selenium.googlecode.com/svn/trunk/docs/api/java/index.html";
	//public static String URL = "http://www.yahoo.com";
	
	public static void main(String[] args) {
		
		if(BrowserInvoke()){
			WebDriver oFrame;
			
			
			oFrame = oWD.switchTo().frame(0);
			oFrame.findElement(By.linkText("org.openqa.selenium")).click();
			
			oWD = oWD.switchTo().defaultContent();
			oFrame = oWD.switchTo().frame(1);
			oFrame.findElement(By.linkText("WebDriver")).click();

			oWD = oWD.switchTo().defaultContent();
			oFrame = oWD.switchTo().frame(2);
			System.out.println(oFrame.getPageSource());

			oWD = oWD.switchTo().defaultContent();			
			
		}
		Browser_Close();
	}

		public static boolean BrowserInvoke(){
		try
		{
		oWD = new FirefoxDriver();
		
		oWD.get(URL);
		}catch(Exception e){
			return false;
		}
		return true;
	}
	
	public static void Browser_Close(){
		oWD.close();
	}
}



