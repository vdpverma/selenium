import org.openqa.selenium.*;
import org.openqa.selenium.firefox.FirefoxDriver;

// ---- To display count of diff. Web Elements...

public class WD0011_Finding_Diff_Type_WebElement 
{
	public static WebDriver oBrowser;
	public static String sUrl = "http://in.yahoo.com";

	public static void main(String[] args) 
	{
		boolean  bIsBrowserOpened;
		
		
		bIsBrowserOpened = OpenBrowser();
		if (bIsBrowserOpened)
		{
			Display_Element_Count();
			
			CloseBrowser();
		}
	}
	
	public static boolean OpenBrowser()
	{
		try
		{
				oBrowser = new FirefoxDriver();
				oBrowser.get(sUrl);
				try
				{
					Thread.sleep(5000L);
				}
				catch (Exception e)
				{
					e.printStackTrace();
				}
				
				return true;
		}
		catch (Exception e)
		{
			System.err.println(e.getMessage());
			return false;
		}
		
		
		
	}
	
	
	public static void Display_Element_Count()
	{
		Get_ElementCount("Link", "//a");
		Get_ElementCount("Image", "//img");
		Get_ElementCount("TextBox", "//input[@type='text']");
		Get_ElementCount("Form Button", "//input[@type='submit' or @type='clear']");
		Get_ElementCount("Html4/5 Button", "//button");
		Get_ElementCount("Radio Button", "//input[@type='radio']");
		Get_ElementCount("CheckBox", "//input[@type='checkbox']");
		Get_ElementCount("Listbox", "//select");
		Get_ElementCount("ActiveX Objects", "//object");
		Get_ElementCount("Multiline Text", "//textarea");

	}
	
	
	public static void Get_ElementCount(String sElementName, String sXpath_of_Element)
	{
		int iCount;
		
		if (!sXpath_of_Element.isEmpty())
		{
			iCount = oBrowser.findElements(By.xpath(sXpath_of_Element)).size();
			System.out.printf("\nNo. of (%s) Element = %d",
					sElementName, iCount);
		}
	}
	
	public static void CloseBrowser()
	{
		oBrowser.close();
	}

}





