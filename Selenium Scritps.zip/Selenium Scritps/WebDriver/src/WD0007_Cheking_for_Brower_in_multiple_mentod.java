import org.openqa.selenium.*;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.UnreachableBrowserException;


//--- Detecting whether Browser Exists or not with multiple methods

public class WD0007_Cheking_for_Brower_in_multiple_mentod 
{
	public static WebDriver oBrowser;
	
	public static void main(String[] args) 
	{
		Show_Browser_Handler();
	}

	public static void Show_Browser_Handler()
	{
		String sBrowserHandler;
		oBrowser = new FirefoxDriver();
	
		if (IsBrowserExist(oBrowser))
		{
			sBrowserHandler = oBrowser.getWindowHandle();
			System.out.println("Handler = " + sBrowserHandler);
			
			oBrowser.close();
		}
		
	}
	
	
	public static boolean IsBrowserExist(WebDriver oBr)
	{
		String sTxt;
		
		try
		{
			sTxt = oBr.getWindowHandle();
			if (!sTxt.isEmpty())
			{
				return true;
			}
			else
			{
				return false;
			}
		}
		catch (UnreachableBrowserException e)
		{
			return false;
		}
		catch (Exception e)
		{
			e.printStackTrace();
			return false;
		}
		
	}
	

	public static boolean IsBrowserExist_Method2(WebDriver oBr)
	{
		String sTxt;
		
		try
		{
			sTxt = oBr.getWindowHandle();
			if (sTxt.length() > 5)
			{
				return true;
			}
			else
			{
				return false;
			}
		}
		catch (UnreachableBrowserException e)
		{
			return false;
		}
		catch (Exception e)
		{
			e.printStackTrace();
			return false;
		}
		
	}	
	
	public static boolean IsBrowserExist_Method3(WebDriver oBr)
	{
		String sTxt;
		
		try
		{
			sTxt = oBr.getWindowHandle();
			if (sTxt.length()>1)
			{
				if (sTxt.startsWith("{"))
					return true;
				else
					return false;
			}
			else
			{
				return false;
			}
		}
		catch (UnreachableBrowserException e)
		{
			return false;
		}
		catch (Exception e)
		{
			e.printStackTrace();
			return false;
		}
		
	}
	
}








