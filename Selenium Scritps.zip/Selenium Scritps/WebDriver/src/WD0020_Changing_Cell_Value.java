import org.openqa.selenium.*;


import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;


public class WD0020_Changing_Cell_Value {

	static WebDriver oWD;
    static Workbook wb = new HSSFWorkbook();
    static String sFileName = "C:\\Selenium Work\\Testing_Tools.xls";
    static String sSheetName = "Sheet1";
    static int iTotalRow,iTotalCol;
     //public static Runtime r;   // r.exit(0);

      public static void main(String[] args)
      {
           String Txt;
          iTotalRow = Get_Total_Row_Count_In_Sheet(sFileName,sSheetName);
          int irow;
          System.out.println("Total No of Rows : " + iTotalRow);
          System.out.println("Original values : ");
          for (irow=1;irow<=iTotalRow;irow++)
          {   
              Txt = Get_Cell_Value(sFileName,sSheetName,irow,0);
              
              System.out.println(irow + ". " + Txt);
          }
          for(irow=1;irow<=iTotalRow;irow++)
          {
        	  if(Set_Cell_Value(sFileName, sSheetName, irow, 0, "pass" + irow))
        	  	  System.out.println(irow + " > Pass");
        	  else
        		  System.out.println(irow + " > Fail");
          }
          
          System.out.println("modified values : ");
          for (irow=1;irow<=iTotalRow;irow++)
          {   
              Txt = Get_Cell_Value(sFileName,sSheetName,irow,0);
              
              System.out.println(irow + ". " + Txt);
          }
         
         }
              
                
        //  ---  Xls file functions  Start

              
                public static int Get_Total_Row_Count_In_Sheet(String sFile,String sSheet)
                {
                    Sheet oSheet;
                      
                    try
                    {
                        InputStream InputFile = new FileInputStream(sFile);
                        wb = WorkbookFactory.create(InputFile);
                        oSheet = wb.getSheet(sSheet);
                        
                        return oSheet.getLastRowNum();
                      
                      
                    } catch (FileNotFoundException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    } catch (InvalidFormatException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    } catch (IOException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }
                    return 0;
                          
                }
              

                public static String Get_Cell_Value(String sFile,String sSheet,int iRow,int iCol)
                {
                    Sheet oSheet;
                    Row oRow;
                    Cell oCell;
                    String sValue = null;
                    try
                    {
                        InputStream InputFile = new FileInputStream(sFile);
                        wb = WorkbookFactory.create(InputFile);
                        oSheet = wb.getSheet(sSheet);
                        oRow = oSheet.getRow(iRow);
                        oCell = oRow.getCell(iCol);
                              
                        sValue = oCell.toString();
                        //sValue = oCell.getStringCellValue();
                        oRow.cellIterator().next();
                      
                    } catch (FileNotFoundException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    } catch (InvalidFormatException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    } catch (IOException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }
                   
                    
                    if(sValue!=null)
                        return sValue;
                    else
                        return "-EOF-";
                }
              
  
                public static boolean Set_Cell_Value(String sFile,String sSheet,int iRow,int iCol,String sValue)
                {
                    Sheet oSheet;
                    Row oRow;
                    Cell oCell;
                    boolean bFlag = true;
                    try
                    {
                        InputStream InputFile = new FileInputStream(sFile);
                        wb = WorkbookFactory.create(InputFile);
                        oSheet = wb.getSheet(sSheet);
                        
                        oRow = oSheet.getRow(iRow);
                        oCell = oRow.getCell(iCol);
                        
                        oCell.setCellValue(sValue);
                        oRow.cellIterator().next();
                        
                    } catch (Exception e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                        bFlag = false;
                    }
            		FileOutputStream fileOut;
					try {
						fileOut = new FileOutputStream(sFile);
					
						wb.write(fileOut);
						fileOut.close();			
					}catch(Exception e){
						bFlag = false;
					}
                    
                    return bFlag;
                }
              
              
        //  ---  Xls file function End      
      
}


//----------------------------------------




// -----  End
