import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.firefox.internal.ProfilesIni;


public class WD0005_Working_with_FireFox_profile {

	
	public static void main(String[] args) {
		
		ProfilesIni AllProfile = new ProfilesIni();
		FirefoxProfile Fprofile = AllProfile.getProfile("Trainer");
		
		WebDriver oBrowser;
		//oBrowser = new FirefoxDriver(); // to invoke browser with default profile
		oBrowser = new FirefoxDriver(Fprofile);//  invokes firefox with trainer profile
		
		oBrowser.get("http://www.yahoo.com");
		oBrowser.manage().window().maximize();
		oBrowser.quit();
		
		
		
	}

}
