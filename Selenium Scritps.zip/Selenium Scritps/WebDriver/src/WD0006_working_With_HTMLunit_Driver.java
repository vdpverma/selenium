import org.openqa.selenium.*;

import org.openqa.selenium.htmlunit.HtmlUnitDriver;


public class WD0006_working_With_HTMLunit_Driver 
{

	public static void main(String[] args) 
	{
		WebDriver oBrowser;
		
		oBrowser = new HtmlUnitDriver(); // no browser invoke
		oBrowser.get("http://www.gmail.com");
		//oBrowser.manage().window().maximize();// to maximize browser
		System.out.println("Title : " + oBrowser.getTitle());
		System.out.println("URL   : " + oBrowser.getCurrentUrl());
		System.out.println("windowHandle  : " + oBrowser.getWindowHandle());
		
		System.out.println("Page Source  : \n\n" + oBrowser.getPageSource());
		
		
		
		
		
		oBrowser.quit(); //  to close the browser
		
		
		
		
	}

}
