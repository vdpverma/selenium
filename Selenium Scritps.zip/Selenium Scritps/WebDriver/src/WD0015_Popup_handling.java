import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;


public class WD0015_Popup_handling {
	
	public static WebDriver oWD;
	public static String URL = "http://www.rediff.com";
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String MainBrowserTitle;
		if(BrowserOpen()){
			MainBrowserTitle = oWD.getTitle().toString();
			
			System.out.println("++++++  "  + MainBrowserTitle);
			if(Check_For_Popup() > 1)
			{
				Get_All_Popup_Window_Title();
				Close_All_Popup_Except_Specified(MainBrowserTitle);
			}
		}
		BrowserClose();
	}

	public static boolean BrowserOpen(){
		
		try{
			oWD = new FirefoxDriver();
			oWD.get(URL);
		}catch(Exception e){
			return false;
		}
		return true;
	}
	
	public static void BrowserClose(){
		oWD.close();
		oWD.quit();
	}
	
	
	
	public static int Check_For_Popup(){
		int PopupCount;
		
		PopupCount = oWD.getWindowHandles().size();
		if(PopupCount == 1)
			System.out.println("No: Popup Window");
		else
			System.out.println("Along with Main Browser, " + (PopupCount-1) + " popup window opened");
		return PopupCount;
	}
	
	public static void Get_All_Popup_Window_Title(){
		int iRow,iPopup;
		Object[] sWindowHandler;
		
		iPopup = Check_For_Popup();
		sWindowHandler = oWD.getWindowHandles().toArray();
		
		for(iRow = 0;iRow < iPopup;iRow++)
		{
			System.out.println((iRow+1)+ "Browser Title : " + oWD.switchTo().window(sWindowHandler[iRow].toString()).getTitle());
		}
	}
	
	
	public static void Close_All_Popup_Except_Specified(String ExpTitle){
		int iRow,iPopup,iMatch =0;
		String ActTitle;
		Object[] sWindowHandler;
		
		iPopup = oWD.getWindowHandles().size();
		sWindowHandler = oWD.getWindowHandles().toArray();
		
		for(iRow = 1;iRow < iPopup;iRow++)
		{
		  ActTitle =  oWD.switchTo().window(sWindowHandler[iRow].toString()).getTitle();
		  if(ActTitle != ExpTitle)
		  {
			  oWD.switchTo().window(sWindowHandler[iRow].toString());
			  oWD.close();
		  }
		  else
			 iMatch =iRow;
		}
		// After clocing all popup seting focus to secified browser
		oWD.switchTo().window(sWindowHandler[iMatch].toString());
	}
	
}
