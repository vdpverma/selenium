import java.util.List;

import org.openqa.selenium.*;
import org.openqa.selenium.firefox.FirefoxDriver;

// ---- To display all individual Web Elements of
//      a particular type with attribute value

public class WD0012_Counting_and_geting_details_of_individual_obj 
{
	public static WebDriver oBrowser;
	public static String sUrl = "http://in.yahoo.com";

	public static void main(String[] args) 
	{
		boolean  bIsBrowserOpened;
		
		
		bIsBrowserOpened = OpenBrowser();
		if (bIsBrowserOpened)
		{
			Display_Element_Count();
			
			CloseBrowser();
		}
	}
	
	public static boolean OpenBrowser()
	{
		try
		{
				oBrowser = new FirefoxDriver();
				oBrowser.get(sUrl);
				try
				{
					Thread.sleep(5000L);
				}
				catch (Exception e)
				{
					e.printStackTrace();
				}
				
				return true;
		}
		catch (Exception e)
		{
			System.err.println(e.getMessage());
			return false;
		}
		
		
		
	}
	
	
	public static void Display_Element_Count()
	{
		Get_All_Elements("Link", "//a", "href");
		Get_All_Elements("Image", "//img", "src");
		Get_All_Elements("TextBox", "//input[@type='text']", "value");
		Get_All_Elements("Form Button", "//input[@type='submit' or @type='clear']", "value");
		Get_All_Elements("Html4/5 Button", "//button", "value");
		Get_All_Elements("Radio Button", "//input[@type='radio']", "value");
		Get_All_Elements("CheckBox", "//input[@type='checkbox']", "value");
		Get_All_Elements("Listbox", "//select", "name");
		Get_All_Elements("ActiveX Objects", "//object", "name");
		Get_All_Elements("Multiline Text", "//textarea", "value");

	}
	
	
	public static void Get_All_Elements(String sElementName, String sXpath_of_Element, String sAttribute)
	{
		int iCount, iElement;
		List<WebElement> oAllElements;
		String sAttrValue="";
		
		if (!sXpath_of_Element.isEmpty())
		{
			oAllElements = oBrowser.findElements(By.xpath(sXpath_of_Element));
			iCount = oAllElements.size();
			
			System.out.printf("\nNo. of (%s) Element = %d",
					sElementName, iCount);
			
			if (iCount>0)
			{
				System.out.printf("\n*****************************");
				
				for(iElement=0;iElement<iCount;iElement++)
				{
					try
					{
						sAttrValue = oAllElements.get(iElement).getAttribute(sAttribute).toString();
					}
					catch(Exception e)
					{
						sAttrValue = "Attribute Not Found!";
					}
					System.out.printf("\n%s (%d of %d) %s = %s",
							sElementName, iElement+1, iCount,
							sAttribute, sAttrValue);
				}
				System.out.printf("\n*********************************\n");
			}
		}
	}
	
	public static void CloseBrowser()
	{
		oBrowser.close();
	}

}





