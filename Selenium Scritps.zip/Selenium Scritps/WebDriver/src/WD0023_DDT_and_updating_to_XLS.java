import org.openqa.selenium.*;
import org.openqa.selenium.firefox.FirefoxDriver;


import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.concurrent.TimeUnit;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;


public class WD0023_DDT_and_updating_to_XLS {

	static WebDriver oWD;
	static String URL = "http://www.bing.com";
    static Workbook wb = new HSSFWorkbook();
    static String sFileName = "C:\\Selenium Work\\Testing_Tools.xls";
    static String sSheetName = "Sheet1";
    static int iTotalRow;
     //public static Runtime r;   // r.exit(0);

      public static void main(String[] args)
      {
           String sSearchTxt,sTotalMatch,sTmp [];
           int irow,i;
           boolean bFlag = true;
           if(Browser_Invoke())
           {
        	   oWD.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
               oWD.manage().timeouts().setScriptTimeout(30, TimeUnit.SECONDS);
        	   
        	   iTotalRow = Get_Total_Row_Count_In_Sheet(sFileName, sSheetName);
        	   
        	   WebElement oSearchTextBox,oSearchButton,oSearchResult;
        	   
        	   for(irow =1;irow<= iTotalRow;irow++)
        	   {
        		   oSearchTextBox = oWD.findElement(By.id("sb_form_q"));
            	   oSearchButton = oWD.findElement(By.id("sb_form_go"));
        		   sSearchTxt = Get_Cell_Value(sFileName, sSheetName, irow, 0);
        	       oSearchTextBox.sendKeys(sSearchTxt);
        	       
        		   oSearchButton.click();
        		   
        		   while(bFlag){
        			   if(oWD.findElement(By.xpath("//*[@id='count']")).isDisplayed())
        				   bFlag = false;
        			   else
        				   bFlag = true;
        		   }
        	       oSearchResult = oWD.findElement(By.xpath("//*[@id='count']"));
        	       sTotalMatch = oSearchResult.getText();
        	      // sTotalMatch = oWD.findElement(By.xpath("//*[@id='count']")).getText();
        	
        	       bFlag = true;
        	       while(bFlag)
        	       {
        	    	   if(oWD.findElement(By.xpath("//*[@id='id_s']")).isDisplayed())
        				   bFlag = false;
        			   else
        				   bFlag = true;
        	       }
        	       
        	       
        	       oWD.navigate().back();
        	
        	       
        	       sTmp = sTotalMatch.split(" ");
        	       
        	       if(Set_Cell_Value(sFileName, sSheetName, irow, 2, sTmp[0]))
        	       {
        	    	   System.out.println("For Search txt : " + sSearchTxt + " ==> Updation done");
        	       }
        	       else
        	    	   System.out.println("For Search txt : " + sSearchTxt + " ==> Updation not done");
        	   }
        	   Browser_Close();
           }
           
           else
        	 System.out.println("Browser Not invoked");  
           
       }
              
           
 // ------------------   Browser invoke
      
      public static boolean Browser_Invoke(){
    	  
    	  try{
    		  oWD = new FirefoxDriver();
    		  oWD.manage().deleteAllCookies();
    		  oWD.get(URL);
    	  }catch(Exception e){
    		  return false;
    	  }
    	  return true;
    	  
      }
      
      public static void Browser_Close(){
    	  oWD.close();
      }
      
      
      
      
        //  ---  Xls file functions  Start

              
                public static int Get_Total_Row_Count_In_Sheet(String sFile,String sSheet)
                {
                    Sheet oSheet;
                      
                    try
                    {
                        InputStream InputFile = new FileInputStream(sFile);
                        wb = WorkbookFactory.create(InputFile);
                        oSheet = wb.getSheet(sSheet);
                        
                        return oSheet.getLastRowNum();
                      
                      
                    } catch (FileNotFoundException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    } catch (InvalidFormatException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    } catch (IOException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }
                    return 0;
                          
                }
              

                public static String Get_Cell_Value(String sFile,String sSheet,int iRow,int iCol)
                {
                    Sheet oSheet;
                    Row oRow;
                    Cell oCell;
                    String sValue = null;
                    try
                    {
                        InputStream InputFile = new FileInputStream(sFile);
                        wb = WorkbookFactory.create(InputFile);
                        oSheet = wb.getSheet(sSheet);
                        oRow = oSheet.getRow(iRow);
                        oCell = oRow.getCell(iCol);
                              
                        sValue = oCell.toString();
                        //sValue = oCell.getStringCellValue();
                        oRow.cellIterator().next();
                      
                    } catch (FileNotFoundException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    } catch (InvalidFormatException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    } catch (IOException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }
                   
                    
                    if(sValue!=null)
                        return sValue;
                    else
                        return "-EOF-";
                }
              
  
                public static boolean Set_Cell_Value(String sFile,String sSheet,int iRow,int iCol,String sTmp)
                {
                    Sheet oSheet;
                    Row oRow;
                    Cell oCell;
                    boolean bFlag = true;
                    try
                    {
                        InputStream InputFile = new FileInputStream(sFile);
                        wb = WorkbookFactory.create(InputFile);
                        oSheet = wb.getSheet(sSheet);
                        
                        oRow = oSheet.getRow(iRow);
                        if (oRow == null)
                        {
                        	oSheet.createRow(iRow);
                        	oRow = oSheet.getRow(iRow);
                        }
                        
                        oCell = oRow.getCell(iCol);
                        if(oCell == null)
                        {
                        	oRow.createCell(iCol);
                        	oCell = oRow.getCell(iCol);
                        }
                        
                        oCell.setCellValue(sTmp);
                        oRow.cellIterator().next();
                        
                    } catch (Exception e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                        bFlag = false;
                    }
            		FileOutputStream fileOut;
					try {
						fileOut = new FileOutputStream(sFile);
					
						wb.write(fileOut);
						fileOut.close();			
					}catch(Exception e){
						bFlag = false;
					}
                    
                    return bFlag;
                }
              
              
        //  ---  Xls file function End      
      
}


//----------------------------------------




// -----  End
