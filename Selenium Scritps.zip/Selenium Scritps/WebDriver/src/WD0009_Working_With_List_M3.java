import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Random;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;


public class WD0009_Working_With_List_M3 {

	public static WebDriver oWD = new FirefoxDriver();
	
	
	public static void main(String[] args) {
		int Maxoption;
		
		oWD.manage().deleteAllCookies();
		oWD.get("http://www.goibibo.com");
		Maxoption = Get_Total_no_option(oWD);
		//Maxoption = 200;
		Get_Selected(oWD);
		Select_Random_option(oWD,Maxoption);
		Get_Selected(oWD);
		Select_Random_option(oWD,Maxoption);
		Get_Selected(oWD);
		Select_Random_option(oWD,Maxoption);
		Get_Selected(oWD);


		
		oWD.quit();
	}
	
	
	
	//   Print all option --- Start
	public static int Get_Total_no_option(WebDriver oWD){
		WebElement oListBox;
		int i;
		oListBox = oWD.findElement(By.id("gi_source"));
		
		
		System.out.println("Total :  " + oListBox.findElements(By.xpath("//option")).size());
		List<WebElement> ls = oListBox.findElements(By.xpath("//option"));
		System.out.println("InDex no\t Name \t Value");
		for(i=0;i<ls.size();i++)
		{
			System.out.println(i + ".  " + ls.get(i).getText() +" \t -> " + ls.get(i).getAttribute("value"));
		}
		return (i+1);
	}
	//  print all option ---- END
	
	// Get_Selected_Oprion  --- Start

	public static void Get_Selected(WebDriver oWD){
		WebElement oListBox;
		Select ListSelect;
		oListBox = oWD.findElement(By.id("gi_source"));
		ListSelect = new Select(oListBox);
		
		System.out.println("Selected = " + ListSelect.getAllSelectedOptions().get(0).getText());	}
	//  Get selected option  ---- END
	
	// select random option -- start
	public static void Select_Random_option(WebDriver oWD,int max){
		WebElement oListBox;
		Select ListSelect;
		Random R = new Random();
		oListBox = oWD.findElement(By.id("gi_source"));
		ListSelect = new Select(oListBox);
		ListSelect.selectByIndex(R.nextInt(max));
	}
	
	
}
