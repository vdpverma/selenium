import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;


public class WD0019_Creating_Xls_file 
{
	static Workbook wb = new HSSFWorkbook();
	static String sFileName;
	
	public static void main(String[] args) 
	{
		sFileName = "C:\\Selenium Work\\Data.xls";
		
		Excel_Examples();
	}

	public static void Excel_Examples()
	{
		Create_ExcelFile();
		Write_to_Excel(0,0,"Selenium");
		Write_to_Excel(1,0,"QTP");
	}
	
	public static void Create_ExcelFile()
	{
	    
	    FileOutputStream fileOut=null;
		try 
		{
			fileOut = new FileOutputStream(sFileName);
			wb.createSheet("Data1");
		    wb.write(fileOut);
		    fileOut.close();			
		} 
		catch (FileNotFoundException e) 
		{
			e.printStackTrace();
		} 
		catch (IOException e)
		{
			e.printStackTrace();
		}

	}
	
	
	public static void Write_to_Excel(int iRow, int iCol, String sValue)
	{
		Sheet oSheet;
		Row oRow;
		Cell oCell;
		
		try 
		{
			InputStream InputFile = new FileInputStream(sFileName);
			wb = WorkbookFactory.create(InputFile);
			oSheet = wb.getSheet("Data1");
			oRow = oSheet.getRow(iRow);
			if (oRow == null)
			{
				oSheet.createRow(iRow);
				oRow = oSheet.getRow(iRow);
			}
			
			oCell = oRow.getCell(iCol);
			
			if (oCell == null)
			{
				oRow.createCell(iCol);
				oCell = oRow.getCell(iCol);
			}
			
			oCell.setCellValue(sValue);
			
			FileOutputStream fileOut = new FileOutputStream(sFileName);
		    wb.write(fileOut);
		    fileOut.close();			
			
			
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InvalidFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
	}
	
}














