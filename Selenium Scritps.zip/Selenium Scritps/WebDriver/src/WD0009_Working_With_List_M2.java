import java.util.List;
import java.util.Random;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;


public class WD0009_Working_With_List_M2 {

	public static WebDriver oWD = new FirefoxDriver();
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		oWD.manage().deleteAllCookies();
		oWD.get("http://www.ebay.com");
		Get_List_Details(); 
		Print_All_List_Options(oWD);
		Get_Selected_Oprion(oWD);
		oWD.quit();
	}
	
	//     Get list details  ---  Start
	public static void Get_List_Details(){
		WebElement oListBox = oWD.findElement(By.xpath("//select[@id='gh-cat']"));
		System.out.println("ListBox Details     : -");
		System.out.println("1. Displayed        :  "  + oListBox.isDisplayed());
		System.out.println("2. TagName          :  "  + oListBox.getTagName());
		System.out.println("3. Hashcode         :  "  + oListBox.hashCode());
		System.out.println("4. Location  X , Y  :  "  + oListBox.getLocation().getX() + " , " + oListBox.getLocation().getY());
		System.out.println("5. Dimension H , W  :  "  + oListBox.getSize().getHeight()+ " , " + oListBox.getSize().getWidth());
		
	}
	//    get list details ---- END
	

	
	
	//   Print all option --- Start
	public static void Print_All_List_Options(WebDriver oWD){
		int iRow;
		WebElement oListBox = oWD.findElement(By.xpath("//select"));
		List<WebElement> AllOptions = oListBox.findElements(By.tagName("option"));
		System.out.println("\n\nOptions in dropdown list : ---- Vaule assigned to it");
		for(iRow=0;iRow<AllOptions.size();iRow++)
		{
			System.out.println(iRow+1 + ". " + AllOptions.get(iRow).getText() + " ----- >" + AllOptions.get(iRow).getAttribute("value"));
		}
	
	}
	//  print all option ---- END
	
	// Get_Selected_Oprion  --- Start
	public static void Get_Selected_Oprion(WebDriver oWD){
		int iRow;
		WebElement oListBox = oWD.findElement(By.xpath("//select"));
		List<WebElement> AllOptions = oListBox.findElements(By.xpath("//option"));
		for(iRow=0;iRow<AllOptions.size();iRow++)
		{
			if (AllOptions.get(iRow).isSelected())
			{
				System.out.println("Selected option  Name : " + AllOptions.get(iRow).getText());
				System.out.println("       Assigned value : " + AllOptions.get(iRow).getAttribute("value"));
			}
		}
	}
	// Get_Selected_Oprion  --- END
/*
	public static void Select_Random_Option_From_List(WebDriver oWD){
		
		int iSelect;
		Random R= new Random();
		WebElement oListBox = oWD.findElement(By.xpath("//select"));
		List<WebElement> AllOptions = oListBox.findElements(By.tagName("option"));
		iSelect = R.nextInt(AllOptions.size()+1);
		
		AllOptions.get(iSelect).click();
			
	}
	//  Select_Random_Option_From_List ---- END

*/

}
