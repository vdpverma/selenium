import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;


public class WD0016_Handling_JavaScript_Alerts {
	public static WebDriver oWD;
	public static String URL = "http://indianrail.gov.in/pnr_Enq.html";
	
	public static void main(String[] args) {
	
		if(BrowserOpen()){
			
			if(Check_For_Alert())
				Handle_Alert();
			
			oWD.findElement(By.name("submit")).click();
			
			if(Check_For_Alert())
				Handle_Alert();

		}
		BrowserClose();
	}
	
	public static boolean BrowserOpen(){
		try{
			oWD = new FirefoxDriver();
			oWD.get(URL);
		}catch(Exception e){
			return false;
		}
		return true;
	}
	public static void BrowserClose(){
		oWD.quit();
	}
	
	public static boolean Check_For_Alert(){
		String Txt;
		try{
			Txt = oWD.switchTo().alert().getText();
		}catch(Exception e){
			System.out.println("No Alert");
			return false;
		}
		System.out.println("Alert Text : " + Txt);
		return true;
	}

	
	public static void Handle_Alert(){
		Alert Jalert;
		Jalert = oWD.switchTo().alert();
		Jalert.accept();
		
	}
	
	

}
