import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;


public class WD0017_Reading_Values_From_Table {
	public static WebDriver oWD;
	public static String URL = "http://finance.yahoo.com";
	public static int iTotalRow,iTotalCol;
	public static void main(String[] args) {
		if(BrowserOpen())
		{
			Get_Table_Size();
			System.out.println("Table size ( Row x Col ) : " + iTotalRow + " x " + iTotalCol);
			Read_Table_Cell_Value();
		}
		BrowserClose();
	}
	
	
	public static boolean BrowserOpen(){
		try{
			oWD = new FirefoxDriver();
			oWD.get(URL);
		}catch(Exception e){
			return false;
		}
		return true;
	}
	public static void BrowserClose(){
		oWD.quit();
	}
	
	
	public static void Get_Table_Size(){
			WebElement oTable;
			String sTblXpath;
			
			
			sTblXpath = "//table[@summary='Currencies']";
			
			oTable = oWD.findElement(By.xpath(sTblXpath)); 
			iTotalRow = oTable.findElements(By.tagName("tr")).size();
			iTotalCol = oTable.findElements(By.tagName("tr")).get(1).findElements(By.tagName("td")).size();
				
				System.out.printf("\n");
			
		}

	public static void Read_Table_Cell_Value(){
		WebElement oTable;
		String sTblXpath,sCellXpath;
		
		int irow, icol;
		
		sTblXpath = "//table[@summary='Currencies']";
		
		oTable = oWD.findElement(By.xpath(sTblXpath)); 
		
		System.out.println("Table content :");
		for(irow=1;irow<iTotalRow;irow++)
		{
			System.out.println(irow +" Row Values : ");
			
			for(icol=1;icol<iTotalCol;icol++)
			{
				sCellXpath = sTblXpath +"/tbody/tr["+irow+"]" + "/td[" + icol +"]";
				System.out.println(oTable.findElement(By.xpath(sCellXpath)).getText());
			}
		}
		
		
	}
	
	
}
