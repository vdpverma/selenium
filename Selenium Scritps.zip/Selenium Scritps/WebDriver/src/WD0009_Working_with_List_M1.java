import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;


public class WD0009_Working_with_List_M1 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int iRow;
		
		WebDriver oWD = new FirefoxDriver();
		WebElement oList,oList1;
		oWD.manage().deleteAllCookies();
		oWD.get("http://www.ebay.com");
		
		
		
		
		// ----------   to get the total no of entries in listbox
		
		
		
		//    Method 
		oList1 = oWD.findElement(By.id("gh-cat-box"));
		oList = oWD.findElement(By.xpath("//select[@id='gh-cat']"));
		
			// know oList points to dropdown list
		
		System.out.println("Default Selection : - " + oList.getText());
		System.out.println("Default Selection : - " + oList1.getText());

			// prints the default selected in DD linst
		
		oList.sendKeys("Baby");
		 
			// its going to select "Baby" from DD list, if and only if "Baby" is their in DD list
		
		List<WebElement> oAllValues = oList.findElements(By.tagName("option"));
			//  oAllValues is list object which consists of all entries of DD List,
			//  to get all Values good to use "findelements By tag names"
			//  know oList will be pointing all values of DD List
			//  oList.getText(); will return all values as a single string, each  entire in a new line 
		
		System.out.println("\n List count : - " + oAllValues.size());
			// prints the total no entries
		
		// ---  to read all values from oAllValues
		System.out.println("Options in dropdown list : ---- Vaule assigned to it");
		for(iRow=0;iRow<oAllValues.size();iRow++)
		{
			System.out.println(iRow+1 + ". " + oAllValues.get(iRow).getText() + " ----- >" + oAllValues.get(iRow).getAttribute("value"));
		}
		for(iRow=0;iRow<1000000;iRow++)
		{
	//		System.out.println(iRow+1 + ". " + oAllValues.get(iRow).getText() + " ----- >" + oAllValues.get(iRow).getAttribute("value"));
		}
		oList.sendKeys("Art122");
		System.out.println("\n\noList.gettext : -\n" + oList.getText());
			// oList is pointing to all options, it will print all options
		
		System.out.println("\n\noList1.gettext : -\n" + oWD.findElement(By.id("gh-cat-box")).getText());
		
		//oWD.quit();
	}

}
