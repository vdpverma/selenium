import org.openqa.selenium.*;
import org.openqa.selenium.firefox.*;


public class WD0003_Invoke_Navigate_Close 
{

	public static void main(String[] args) 
	{
		WebDriver oBrowser;
		
		oBrowser = new FirefoxDriver(); // for firefox
		oBrowser.get("http://www.gmail.com");
		oBrowser.manage().window().maximize();// to maximize browser
		oBrowser.quit(); //  to close the browser
		
	}

}
